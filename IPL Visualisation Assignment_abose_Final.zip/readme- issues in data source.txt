in calculation of orange, purple cap the filter in malfunctioning 
the auto filter by top 10 sum of runs is excluding the highest score each time for each season

i had to use atleast filter in measure to resolve this issue